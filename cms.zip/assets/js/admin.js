/* Universal CMS — Admin behaviour: builder, repeaters, media picker */
(function () {
  'use strict';
  var CSRF = (document.querySelector('meta[name=csrf-token]') || {}).content || '';
  var BASE = document.body.getAttribute('data-base') || '';

  function url(path){ return (window.CMS_BASE || '') + path; }

  /* ---- Collapsible builder sections ---- */
  document.addEventListener('click', function (e) {
    var head = e.target.closest('.builder-head');
    if (head && !e.target.closest('.actions')) {
      var body = head.parentElement.querySelector('.builder-body');
      if (body) body.classList.toggle('open');
    }
  });

  /* ---- Sortable: page sections ---- */
  var secList = document.getElementById('sectionList');
  if (secList && window.Sortable) {
    Sortable.create(secList, {
      handle: '.builder-head', animation: 150,
      onEnd: function () {
        var ids = Array.from(secList.querySelectorAll('[data-section-id]')).map(function (el) { return el.getAttribute('data-section-id'); });
        fetch(window.CMS_REORDER_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-TOKEN': CSRF, 'X-Requested-With': 'XMLHttpRequest' },
          body: ids.map(function (id, i) { return 'order[' + i + ']=' + encodeURIComponent(id); }).join('&')
        });
      }
    });
  }

  /* ---- Sortable: menu items ---- */
  var menuList = document.getElementById('menuItemList');
  if (menuList && window.Sortable) {
    Sortable.create(menuList, {
      handle: '.drag', animation: 150,
      onEnd: function () {
        var ids = Array.from(menuList.querySelectorAll('[data-item-id]')).map(function (el) { return el.getAttribute('data-item-id'); });
        fetch(window.CMS_MENU_REORDER_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-TOKEN': CSRF, 'X-Requested-With': 'XMLHttpRequest' },
          body: ids.map(function (id, i) { return 'order[' + i + ']=' + encodeURIComponent(id); }).join('&')
        });
      }
    });
  }

  /* ---- Repeater add/remove ---- */
  document.addEventListener('click', function (e) {
    var addBtn = e.target.closest('[data-repeater-add]');
    if (addBtn) {
      e.preventDefault();
      var wrap = addBtn.closest('.repeater');
      var tpl = wrap.querySelector('template');
      var idx = wrap.querySelectorAll('.repeater-item').length;
      var html = tpl.innerHTML.replace(/__i__/g, idx);
      var holder = wrap.querySelector('.repeater-items');
      holder.insertAdjacentHTML('beforeend', html);
    }
    var rm = e.target.closest('.remove-item');
    if (rm) { e.preventDefault(); rm.closest('.repeater-item').remove(); }
  });

  /* ---- Media picker ---- */
  var activeTarget = null, activeMode = 'single';
  window.openMediaPicker = function (inputId, mode) {
    activeTarget = inputId; activeMode = mode || 'single';
    var modalEl = document.getElementById('mediaModal');
    var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
    loadMedia();
    modal.show();
  };

  function loadMedia(q) {
    var grid = document.getElementById('mediaModalGrid');
    if (!grid) return;
    grid.innerHTML = '<div class="text-center py-4 text-muted">Loading…</div>';
    fetch(window.CMS_PICKER_URL + (q ? ('?q=' + encodeURIComponent(q)) : ''))
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (!data.items || !data.items.length) { grid.innerHTML = '<p class="text-muted text-center py-4">No media yet. Upload some in the Media Library.</p>'; return; }
        grid.innerHTML = data.items.map(function (m) {
          var isImg = (m.mime || '').indexOf('image') === 0;
          return '<div class="media-tile" style="cursor:pointer" data-path="' + m.path + '" data-url="' + m.url + '">' +
            (isImg ? '<img src="' + m.url + '">' : '<div class="m-name p-3"><i class="fa fa-file"></i></div>') +
            '<div class="m-name">' + m.name + '</div></div>';
        }).join('');
      });
  }

  document.addEventListener('click', function (e) {
    var tile = e.target.closest('#mediaModalGrid .media-tile');
    if (tile && activeTarget) {
      var path = tile.getAttribute('data-path');
      var url = tile.getAttribute('data-url');
      if (activeMode === 'multi') {
        addGalleryImage(activeTarget, path, url);
      } else {
        var input = document.getElementById(activeTarget);
        if (input) { input.value = path; }
        var prev = document.getElementById(activeTarget + '_preview');
        if (prev) { prev.src = url; prev.style.display = 'block'; }
      }
      bootstrap.Modal.getInstance(document.getElementById('mediaModal')).hide();
    }
  });

  var searchBox = document.getElementById('mediaModalSearch');
  if (searchBox) {
    var t; searchBox.addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { loadMedia(searchBox.value); }, 300); });
  }

  /* ---- Gallery multi-image field ---- */
  window.addGalleryImage = function (containerId, path, url) {
    var c = document.getElementById(containerId);
    if (!c) return;
    var name = c.getAttribute('data-name');
    var div = document.createElement('div');
    div.className = 'gallery-thumb position-relative';
    div.style.cssText = 'width:90px;height:70px;display:inline-block;margin:4px';
    div.innerHTML = '<img src="' + url + '" style="width:100%;height:100%;object-fit:cover;border-radius:8px">' +
      '<button type="button" class="btn btn-sm btn-danger position-absolute top-0 end-0 p-0 px-1 remove-gallery">&times;</button>' +
      '<input type="hidden" name="' + name + '" value="' + path + '">';
    c.appendChild(div);
  };
  document.addEventListener('click', function (e) {
    if (e.target.closest('.remove-gallery')) { e.target.closest('.gallery-thumb').remove(); }
  });

  /* ---- Slug auto-fill ---- */
  document.querySelectorAll('[data-slug-source]').forEach(function (src) {
    var target = document.querySelector(src.getAttribute('data-slug-source'));
    if (!target) return;
    src.addEventListener('input', function () {
      if (target.dataset.touched) return;
      target.value = src.value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    });
    target.addEventListener('input', function () { target.dataset.touched = '1'; });
  });
})();
