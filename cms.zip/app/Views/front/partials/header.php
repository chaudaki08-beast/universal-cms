<?php
$renderMenu = function (array $items) use (&$renderMenu) {
    foreach ($items as $it):
        $hasKids = !empty($it['children']); ?>
        <li class="nav-item <?= $hasKids ? 'dropdown' : '' ?>">
          <a class="nav-link <?= $hasKids ? 'dropdown-toggle' : '' ?>"
             href="<?= e($it['url']) ?>" target="<?= e($it['target']) ?>"
             <?= $hasKids ? 'data-bs-toggle="dropdown"' : '' ?>>
            <?php if (!empty($it['icon'])): ?><i class="fa <?= e($it['icon']) ?> me-1"></i><?php endif; ?>
            <?= e($it['label']) ?>
          </a>
          <?php if ($hasKids): ?>
            <ul class="dropdown-menu">
              <?php foreach ($it['children'] as $c): ?>
                <li><a class="dropdown-item" href="<?= e($c['url']) ?>" target="<?= e($c['target']) ?>"><?= e($c['label']) ?></a></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </li>
    <?php endforeach;
};
?>
<header class="site-header <?= !empty($theme['sticky_header']) ? 'is-sticky' : '' ?>">
  <?php if (!empty($contact['phone']) || !empty($contact['email'])): ?>
  <div class="topbar">
    <div class="container d-flex justify-content-between align-items-center">
      <div class="small">
        <?php if (!empty($contact['phone'])): ?><span class="me-3"><i class="fa fa-phone me-1"></i><?= e($contact['phone']) ?></span><?php endif; ?>
        <?php if (!empty($contact['email'])): ?><span><i class="fa fa-envelope me-1"></i><?= e($contact['email']) ?></span><?php endif; ?>
      </div>
      <div class="social-icons">
        <?php foreach (['facebook'=>'fa-facebook-f','instagram'=>'fa-instagram','twitter'=>'fa-x-twitter','linkedin'=>'fa-linkedin-in','youtube'=>'fa-youtube'] as $k=>$icon):
          if (!empty($social[$k])): ?>
            <a href="<?= e($social[$k]) ?>" target="_blank" rel="noopener" aria-label="<?= $k ?>"><i class="fa-brands <?= $icon ?>"></i></a>
        <?php endif; endforeach; ?>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <nav class="navbar navbar-expand-lg main-nav">
    <div class="container">
      <a class="navbar-brand" href="<?= base_url('/') ?>">
        <?php if (!empty($site['logo'])): ?>
          <img src="<?= e(uploads_url($site['logo'])) ?>" alt="<?= e($site['name']) ?>" height="42">
        <?php else: ?>
          <span class="brand-text"><?= e($site['name']) ?></span>
        <?php endif; ?>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto align-items-lg-center">
          <?php $renderMenu($primaryMenu); ?>
        </ul>
      </div>
    </div>
  </nav>
</header>
