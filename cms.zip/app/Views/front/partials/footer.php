<?php $year = date('Y'); ?>
<footer class="site-footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4">
        <?php if (!empty($site['logo'])): ?>
          <img src="<?= e(uploads_url($site['logo'])) ?>" alt="<?= e($site['name']) ?>" height="40" class="mb-3">
        <?php else: ?>
          <h5 class="footer-brand"><?= e($site['name']) ?></h5>
        <?php endif; ?>
        <p class="text-muted-2"><?= e($site['tagline'] ?? '') ?></p>
        <div class="social-icons mt-3">
          <?php foreach (['facebook'=>'fa-facebook-f','instagram'=>'fa-instagram','twitter'=>'fa-x-twitter','linkedin'=>'fa-linkedin-in','youtube'=>'fa-youtube'] as $k=>$icon):
            if (!empty($social[$k])): ?>
              <a href="<?= e($social[$k]) ?>" target="_blank" rel="noopener"><i class="fa-brands <?= $icon ?>"></i></a>
          <?php endif; endforeach; ?>
        </div>
      </div>

      <div class="col-lg-4">
        <h6 class="footer-title">Quick Links</h6>
        <ul class="footer-links">
          <?php foreach (($footerMenu ?: $primaryMenu) as $it): ?>
            <li><a href="<?= e($it['url']) ?>"><?= e($it['label']) ?></a></li>
          <?php endforeach; ?>
        </ul>
      </div>

      <div class="col-lg-4">
        <h6 class="footer-title">Get in Touch</h6>
        <ul class="footer-contact">
          <?php if (!empty($contact['address'])): ?><li><i class="fa fa-location-dot me-2"></i><?= e($contact['address']) ?></li><?php endif; ?>
          <?php if (!empty($contact['phone'])): ?><li><i class="fa fa-phone me-2"></i><?= e($contact['phone']) ?></li><?php endif; ?>
          <?php if (!empty($contact['email'])): ?><li><i class="fa fa-envelope me-2"></i><?= e($contact['email']) ?></li><?php endif; ?>
        </ul>
      </div>
    </div>
    <hr class="footer-divider">
    <div class="text-center small text-muted-2">
      &copy; <?= $year ?> <?= e($site['name']) ?>. All rights reserved.
    </div>
  </div>
</footer>
