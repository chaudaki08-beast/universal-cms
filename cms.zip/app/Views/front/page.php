<?php
/** @var array $sections */
$sections = $sections ?? [];

foreach ($sections as $section):
    $type = $section['type'];
    $data = json_field($section['data']);
    $set  = json_field($section['settings']);
    $file = APP_PATH . '/Views/front/sections/' . preg_replace('/[^a-z]/', '', $type) . '.php';

    $pad = ['none'=>'py-0','sm'=>'py-3','md'=>'py-5','lg'=>'section-pad','xl'=>'section-pad-xl'][$set['padding'] ?? 'lg'] ?? 'section-pad';
    $bg  = $set['bg'] ?? '';
    $styleBg = $bg ? 'style="background:' . e($bg) . '"' : '';
    ?>
    <section id="section-<?= (int) $section['id'] ?>" class="cms-section cms-<?= e($type) ?> <?= $pad ?>" <?= $styleBg ?>>
      <?php
      if (is_file($file)) {
          require $file;          // has $data, $set in scope
      } else {
          echo '<div class="container"><em>Unknown section: ' . e($type) . '</em></div>';
      }
      ?>
    </section>
<?php endforeach; ?>

<?php if (empty($sections)): ?>
  <div class="container section-pad text-center">
    <h2>This page has no sections yet.</h2>
    <p class="text-muted">Add sections from the admin page builder.</p>
  </div>
<?php endif; ?>
